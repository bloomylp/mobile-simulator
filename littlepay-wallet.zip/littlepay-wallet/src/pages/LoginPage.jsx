// src/pages/LoginPage.jsx
import { useRef, useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { login } from '../utils/auth.js'

export function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const from = location.state?.from?.pathname ?? '/home'
  const [loading, setLoading] = useState(false)
  const timerRef = useRef(null)

  function handleLogin() {
    if (loading) return
    setLoading(true)
    timerRef.current = setTimeout(() => {
      login()
      setLoading(false)
      navigate(from, { replace: true })
    }, 800)
  }

  return (
    <div className="min-h-full relative flex flex-col">
      {/* Full-screen login image */}
      <img
        src="/login.png"
        alt="Welcome to Traveller Wallet"
        className="absolute inset-0 w-full h-full object-cover"
        draggable="false"
      />

      {/* Overlay buttons matching image layout */}
      <div className="absolute bottom-[117px] left-0 right-0 px-6 flex flex-col items-center">
        <button
          onClick={handleLogin}
          disabled={loading}
          className="bg-white text-[#2DB87E] font-semibold text-sm rounded-full py-[12.5px] cursor-pointer hover:bg-white/90 active:scale-95 transition-all duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-white disabled:opacity-70"
          style={{ width: 'calc(100% - 50px)' }}
        >
          {loading ? 'Signing in…' : 'Proceed to Login'}
        </button>
      </div>
    </div>
  )
}
