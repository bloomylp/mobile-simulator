// src/utils/cardsStore.js
const EXTRA_KEY   = 'lp_extra_cards'
const BALANCE_KEY = 'lp_balances'

export function getExtraCards() {
  try {
    return JSON.parse(sessionStorage.getItem(EXTRA_KEY) ?? '[]')
  } catch {
    return []
  }
}

export function addExtraCard(card) {
  try {
    const existing = getExtraCards()
    sessionStorage.setItem(EXTRA_KEY, JSON.stringify([...existing, card]))
  } catch {}
}

// Balance overrides — keyed by card id
function getBalances() {
  try {
    return JSON.parse(sessionStorage.getItem(BALANCE_KEY) ?? '{}')
  } catch {
    return {}
  }
}

export function topUpCard(cardId, amount) {
  try {
    const balances = getBalances()
    balances[cardId] = (balances[cardId] ?? 0) + amount
    sessionStorage.setItem(BALANCE_KEY, JSON.stringify(balances))
  } catch {}
}

export function getCardBalance(cardId, defaultBalance = 0) {
  const balances = getBalances()
  return balances[cardId] ?? defaultBalance
}

let _seq = 1

export function buildNewCard() {
  const seq = _seq++
  const last4 = String(1000 + seq * 37).slice(-4)
  return {
    id: `card-new-${Date.now()}`,
    name: 'John Smith',
    pan: `•••• •••• •••• ${last4}`,
    panFull: `0000 0000 0000 ${last4}`,
    expiry: '12/28',
    status: 'new',
    balance: 0,
    spent: 0,
    createdAt: (() => { const d = new Date(); const p = n => String(n).padStart(2,'0'); return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}` })(),
  }
}
