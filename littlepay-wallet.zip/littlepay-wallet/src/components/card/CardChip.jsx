// src/components/card/CardChip.jsx
import { RefreshCw, Trash2, X } from 'lucide-react'

const STATUS_LABEL = { active: 'Active', pending: 'Pending', frozen: 'Frozen', new: 'New' }

const FRONT_GRAD = 'linear-gradient(135deg, #4CC48A 0%, #2DB87E 60%, #1A7A50 100%)'
const BACK_GRAD  = 'linear-gradient(135deg, #1A7A50 0%, #0D4F34 100%)'

export function CardChip({
  card,
  showStatus  = false,
  flipped     = false,
  onFlipBack,
  onRefresh,
  onDelete,
}) {
  return (
    <div style={{ perspective: '1200px' }}>
      <div
        role="region"
        aria-label={`${card.status} card ending ${card.pan.slice(-4)}`}
        style={{
          position:        'relative',
          height:          '160px',
          transformStyle:  'preserve-3d',
          transition:      'transform 0.55s cubic-bezier(0.4, 0, 0.2, 1)',
          transform:       flipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
        }}
      >
        {/* ── Front face ── */}
        <div
          className="absolute inset-0 rounded-2xl p-5 overflow-hidden select-none"
          style={{ backfaceVisibility: 'hidden', background: FRONT_GRAD }}
        >
          <div className="absolute -top-8 -right-8 w-36 h-36 rounded-full opacity-10 bg-white" />
          <div className="absolute -bottom-6 -left-6 w-28 h-28 rounded-full opacity-10 bg-white" />

          <div className="relative flex items-center justify-between mb-6">
            {showStatus ? (
              <span className="bg-white/20 text-white text-xs font-semibold px-2.5 py-1 rounded-full">
                {STATUS_LABEL[card.status] ?? card.status}
              </span>
            ) : (
              <span className="text-white/80 text-xs font-medium tracking-wide uppercase">
                Traveller Wallet
              </span>
            )}
            <span className="text-white font-bold text-sm tracking-tight">
              little<span className="text-[#E8F7F0]">pay</span>
            </span>
          </div>

          <div className="relative mb-3">
            <p className="text-white font-semibold text-lg leading-tight">{card.name}</p>
          </div>

          <div className="relative flex items-end justify-between">
            <p className="text-white/90 font-mono text-sm tracking-widest">{card.pan}</p>
            <p className="text-white/80 text-xs font-medium">{card.expiry}</p>
          </div>
        </div>

        {/* ── Back face ── */}
        <div
          className="absolute inset-0 rounded-2xl p-5 overflow-hidden select-none"
          style={{
            backfaceVisibility: 'hidden',
            transform:          'rotateY(180deg)',
            background:         BACK_GRAD,
          }}
        >
          <div className="absolute -top-8 -right-8 w-36 h-36 rounded-full opacity-10 bg-white" />
          <div className="absolute -bottom-6 -left-6 w-28 h-28 rounded-full opacity-10 bg-white" />

          <div className="relative flex justify-end mb-3">
            <button
              onClick={onFlipBack}
              className="text-white/60 hover:text-white rounded-full p-1 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-white transition-colors duration-150"
              aria-label="Close card management"
            >
              <X size={16} />
            </button>
          </div>

          <div className="relative flex flex-col gap-2.5">
            <button
              onClick={onRefresh}
              className="flex items-center justify-center gap-2 w-full bg-white/20 hover:bg-white/30 text-white text-sm font-semibold rounded-xl py-2.5 cursor-pointer transition-colors duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-white min-h-[44px]"
            >
              <RefreshCw size={14} aria-hidden="true" />
              Refresh card
            </button>
            <button
              onClick={onDelete}
              className="flex items-center justify-center gap-2 w-full bg-red-500/20 hover:bg-red-500/30 text-red-200 hover:text-red-100 text-sm font-semibold rounded-xl py-2.5 cursor-pointer transition-colors duration-150 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-300 min-h-[44px]"
            >
              <Trash2 size={14} aria-hidden="true" />
              Delete card
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
